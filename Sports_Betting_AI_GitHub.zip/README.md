# 🏆 Sports Betting AI

Dashboard para analizar MLB, NFL, NBA, NHL y UFC.

Incluye:
- Juegos próximos
- Noticias recientes
- Cuotas (con The Odds API)
- Probabilidad base
- Indicador de riesgo
- Estructura preparada para agregar lesiones, estadísticas y movimiento de líneas

## Ejecutar

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Cuotas reales

Crea un secret llamado `ODDS_API_KEY`.

En Streamlit Cloud:
Settings → Secrets

```toml
ODDS_API_KEY = "TU_API_KEY"
```

No subas tu API key a GitHub.

## Nota

La primera versión usa un modelo base para que el proyecto funcione desde el principio.
Las lesiones y estadísticas avanzadas deben conectarse a fuentes de datos específicas antes
de considerar las probabilidades como una señal de apuesta.
